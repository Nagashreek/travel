<?php
   
   $id= $_GET['id'];

   $conn=mysqli_connect('localhost','root','','vehicle');
   $sql="DELETE FROM user WHERE user_id='$id'";
   $result=mysqli_query($conn,$sql);
   if(mysqli_query($conn,$sql)){
       header("Location: user.php");
   }else{
         echo "Not deleted";
   }
   
?>
